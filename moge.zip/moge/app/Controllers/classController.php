<?php

namespace App\Controllers;

use App\Models\Mparticipant;

class classController extends BaseController
{
    public function index()
    {
        return view('class');
    }
}
