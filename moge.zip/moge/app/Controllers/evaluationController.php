<?php

namespace App\Controllers;

use App\Models\Mparticipant;

class evaluationController extends BaseController
{
    public function index()
    {
        $participant = new Mparticipant();
        $data = array(
            'participants' => $participant->getAllParticipants()
        );
        return view('evaluation', $data);
    }

    public function import()
    {
        return view('importParticipants');
    }
}
