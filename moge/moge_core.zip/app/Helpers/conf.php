
<?php



define('CLIENT_ID', 'HmiLi8cnQ7qYMxieLjVgYA');
define('CLIENT_SECRET', 'CGhd5l9MpDUefIz7Szw4w3b5tMroBssR');
define('REDIRECT_URI', 'https://c430-114-5-253-136.ap.ngrok.io/callback'); ?>