<?php

namespace App\Libraries;

class detailClass
{
    public $class_id;

    public function putClassId($class_id)
    {
        $this->class_id = $class_id;
    }
}
