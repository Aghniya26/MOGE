<?php

namespace App\Libraries;

class zoomAuth
{
    public $CLIENT_ID = 'HmiLi8cnQ7qYMxieLjVgYA';
    public $CLIENT_SECRET = 'CGhd5l9MpDUefIz7Szw4w3b5tMroBssR';
    public $REDIRECT_URI = 'https://0609-114-5-210-247.ap.ngrok.io/callback';
}
